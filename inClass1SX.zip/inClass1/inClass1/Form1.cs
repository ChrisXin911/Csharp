namespace inClass1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                label4.Text = "Number of Years";
            }
            else { label4.Text = "Number of Months"; }

        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            txtLoanAmount.Clear();
            txtInterestRate.Clear();
            txtTerms.Clear();
            lblAnswer.Text = "";

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double loanAmount = double.Parse(txtLoanAmount.Text);
                decimal rateOfYear = (decimal)(double.Parse(txtInterestRate.Text) / 100);
                decimal interest = rateOfYear / 12;
                int terms = 0;

                //by month
                if (comboBox1.SelectedIndex == 0)
                {
                    terms = int.Parse(txtTerms.Text);
                }
                //by year
                if (comboBox1.SelectedIndex == 1)
                {
                    terms = int.Parse(txtTerms.Text) * 12;
                }
                double ans;
                //the formula: loan*rate*��1��rate��^terms/[��1��rate��^terms��1]
                double temp = Math.Pow((1 + (double)interest), terms);
                ans = (loanAmount * (double)interest * temp) / (temp - 1);
                if (comboBox1.SelectedIndex == 0)
                {
                    lblAnswer.Text = "Monthly Payment - $" + ans.ToString("0.00");
                }
                if (comboBox1.SelectedIndex == 1)
                {
                    ans *= 12;
                    lblAnswer.Text = "Yearly Payment - $" + ans.ToString("0.00");
                }
            }
            catch
            {
                MessageBox.Show("Invalid input, please try again!", "Sorry!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}